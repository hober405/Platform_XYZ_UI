all data are sampled in 1kHz.
magnets are 5 Vpp, placing at (x, y)=(207, 227)

center10_20_40Hz_10s.log

sensor is placed at the center of megnet.
record for 10 s.
x: 20Hz
y: 40Hz
z: 10Hz

magnetic_map_megnet_10_20_40Hz_s1k.log

x: from 207 to 187, 5mm a recording, total 4 recordings
y: from 227 to 207, 5mm a recording, total 4 recordings
z: from 0 to 15, 5mm a recording, total 3 recordings
total: 4*4*3=48 points

x: 20Hz
y: 40Hz
z: 10Hz


magnetic_map_megnet_25_50_100Hz_s1k.log

x: from 207 to 187, 5mm a recording, total 4 recordings
y: from 227 to 207, 5mm a recording, total 4 recordings
z: from 0 to 15, 5mm a recording, total 3 recordings
total: 4*4*3=48 points

x: 25Hz
y: 50Hz
z: 100Hz

